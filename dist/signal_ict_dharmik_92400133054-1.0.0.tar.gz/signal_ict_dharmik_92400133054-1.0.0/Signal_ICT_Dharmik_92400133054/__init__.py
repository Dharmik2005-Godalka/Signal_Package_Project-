'''This is my 4th created file, in this file import all 3 module's different functions like unit-step, impulse, ramp, etc.
so , this is basically we can say that a small package type...

'''
from .unitary_signals import unit_step, unit_impulse, ramp_signal
from .trigonometric_signals import sine_wave, cosine_wave, exponential_signal
from .operations import time_shift, time_scale, signal_addition, signal_multiplication

__all__ = [
    "unit_step",
    "unit_impulse",
    "ramp_signal",
    "sine_wave",
    "cosine_wave",
    "exponential_signal",
    "time_shift",
    "time_scale",
    "signal_addition",
    "signal_multiplication",
    ]
