# Signal ICT Package

**Student Name:** Dharmik 
**Enrollment No:** 92400133054
---

## Description
This package implements basic signals and operations using **Python, NumPy, and Matplotlib**.  
It includes:
- Unitary signals (step, impulse, ramp)
- Trigonometric signals (sine, cosine)
- Operations (time shift, addition, multiplication)
